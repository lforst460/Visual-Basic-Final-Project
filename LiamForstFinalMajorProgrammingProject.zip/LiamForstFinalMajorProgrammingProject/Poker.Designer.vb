﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Poker
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.rankLabel = New System.Windows.Forms.Label()
        Me.suitLabel = New System.Windows.Forms.Label()
        Me.cardOneLabel = New System.Windows.Forms.Label()
        Me.cardTwoLabel = New System.Windows.Forms.Label()
        Me.cardThreeLabel = New System.Windows.Forms.Label()
        Me.cardFourLabel = New System.Windows.Forms.Label()
        Me.CardFiveLabel = New System.Windows.Forms.Label()
        Me.cardOneRankText = New System.Windows.Forms.TextBox()
        Me.cardTwoRankText = New System.Windows.Forms.TextBox()
        Me.cardThreeRankText = New System.Windows.Forms.TextBox()
        Me.cardFourRankText = New System.Windows.Forms.TextBox()
        Me.cardFiveRankText = New System.Windows.Forms.TextBox()
        Me.cardOneSuitText = New System.Windows.Forms.TextBox()
        Me.cardTwoSuitText = New System.Windows.Forms.TextBox()
        Me.cardThreeSuitText = New System.Windows.Forms.TextBox()
        Me.cardFourSuitText = New System.Windows.Forms.TextBox()
        Me.cardFiveSuitText = New System.Windows.Forms.TextBox()
        Me.displayButton = New System.Windows.Forms.Button()
        Me.handDisplay = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'rankLabel
        '
        Me.rankLabel.AutoSize = True
        Me.rankLabel.Location = New System.Drawing.Point(16, 16)
        Me.rankLabel.Name = "rankLabel"
        Me.rankLabel.Size = New System.Drawing.Size(135, 51)
        Me.rankLabel.TabIndex = 0
        Me.rankLabel.Text = "Rank:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Ace=1, Jack=11," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Queen=12, King=13"
        '
        'suitLabel
        '
        Me.suitLabel.AutoSize = True
        Me.suitLabel.Location = New System.Drawing.Point(216, 9)
        Me.suitLabel.Name = "suitLabel"
        Me.suitLabel.Size = New System.Drawing.Size(132, 51)
        Me.suitLabel.TabIndex = 1
        Me.suitLabel.Text = "Suit: Diamonds=D," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Hearts=H, Clubs=C," & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Spades=S"
        '
        'cardOneLabel
        '
        Me.cardOneLabel.AutoSize = True
        Me.cardOneLabel.Location = New System.Drawing.Point(33, 81)
        Me.cardOneLabel.Name = "cardOneLabel"
        Me.cardOneLabel.Size = New System.Drawing.Size(58, 17)
        Me.cardOneLabel.TabIndex = 2
        Me.cardOneLabel.Text = "Card #1"
        '
        'cardTwoLabel
        '
        Me.cardTwoLabel.AutoSize = True
        Me.cardTwoLabel.Location = New System.Drawing.Point(33, 111)
        Me.cardTwoLabel.Name = "cardTwoLabel"
        Me.cardTwoLabel.Size = New System.Drawing.Size(58, 17)
        Me.cardTwoLabel.TabIndex = 3
        Me.cardTwoLabel.Text = "Card #2"
        '
        'cardThreeLabel
        '
        Me.cardThreeLabel.AutoSize = True
        Me.cardThreeLabel.Location = New System.Drawing.Point(33, 147)
        Me.cardThreeLabel.Name = "cardThreeLabel"
        Me.cardThreeLabel.Size = New System.Drawing.Size(58, 17)
        Me.cardThreeLabel.TabIndex = 4
        Me.cardThreeLabel.Text = "Card #3"
        '
        'cardFourLabel
        '
        Me.cardFourLabel.AutoSize = True
        Me.cardFourLabel.Location = New System.Drawing.Point(33, 181)
        Me.cardFourLabel.Name = "cardFourLabel"
        Me.cardFourLabel.Size = New System.Drawing.Size(58, 17)
        Me.cardFourLabel.TabIndex = 5
        Me.cardFourLabel.Text = "Card #4"
        '
        'CardFiveLabel
        '
        Me.CardFiveLabel.AutoSize = True
        Me.CardFiveLabel.Location = New System.Drawing.Point(33, 221)
        Me.CardFiveLabel.Name = "CardFiveLabel"
        Me.CardFiveLabel.Size = New System.Drawing.Size(58, 17)
        Me.CardFiveLabel.TabIndex = 6
        Me.CardFiveLabel.Text = "Card #5"
        '
        'cardOneRankText
        '
        Me.cardOneRankText.Location = New System.Drawing.Point(97, 81)
        Me.cardOneRankText.Name = "cardOneRankText"
        Me.cardOneRankText.Size = New System.Drawing.Size(27, 22)
        Me.cardOneRankText.TabIndex = 7
        '
        'cardTwoRankText
        '
        Me.cardTwoRankText.Location = New System.Drawing.Point(97, 111)
        Me.cardTwoRankText.Name = "cardTwoRankText"
        Me.cardTwoRankText.Size = New System.Drawing.Size(27, 22)
        Me.cardTwoRankText.TabIndex = 8
        '
        'cardThreeRankText
        '
        Me.cardThreeRankText.Location = New System.Drawing.Point(97, 147)
        Me.cardThreeRankText.Name = "cardThreeRankText"
        Me.cardThreeRankText.Size = New System.Drawing.Size(27, 22)
        Me.cardThreeRankText.TabIndex = 9
        '
        'cardFourRankText
        '
        Me.cardFourRankText.Location = New System.Drawing.Point(97, 181)
        Me.cardFourRankText.Name = "cardFourRankText"
        Me.cardFourRankText.Size = New System.Drawing.Size(27, 22)
        Me.cardFourRankText.TabIndex = 10
        '
        'cardFiveRankText
        '
        Me.cardFiveRankText.Location = New System.Drawing.Point(97, 221)
        Me.cardFiveRankText.Name = "cardFiveRankText"
        Me.cardFiveRankText.Size = New System.Drawing.Size(27, 22)
        Me.cardFiveRankText.TabIndex = 11
        '
        'cardOneSuitText
        '
        Me.cardOneSuitText.Location = New System.Drawing.Point(219, 81)
        Me.cardOneSuitText.Name = "cardOneSuitText"
        Me.cardOneSuitText.Size = New System.Drawing.Size(27, 22)
        Me.cardOneSuitText.TabIndex = 12
        '
        'cardTwoSuitText
        '
        Me.cardTwoSuitText.Location = New System.Drawing.Point(219, 111)
        Me.cardTwoSuitText.Name = "cardTwoSuitText"
        Me.cardTwoSuitText.Size = New System.Drawing.Size(27, 22)
        Me.cardTwoSuitText.TabIndex = 13
        '
        'cardThreeSuitText
        '
        Me.cardThreeSuitText.Location = New System.Drawing.Point(219, 147)
        Me.cardThreeSuitText.Name = "cardThreeSuitText"
        Me.cardThreeSuitText.Size = New System.Drawing.Size(27, 22)
        Me.cardThreeSuitText.TabIndex = 14
        '
        'cardFourSuitText
        '
        Me.cardFourSuitText.Location = New System.Drawing.Point(219, 181)
        Me.cardFourSuitText.Name = "cardFourSuitText"
        Me.cardFourSuitText.Size = New System.Drawing.Size(27, 22)
        Me.cardFourSuitText.TabIndex = 15
        '
        'cardFiveSuitText
        '
        Me.cardFiveSuitText.Location = New System.Drawing.Point(219, 221)
        Me.cardFiveSuitText.Name = "cardFiveSuitText"
        Me.cardFiveSuitText.Size = New System.Drawing.Size(27, 22)
        Me.cardFiveSuitText.TabIndex = 16
        '
        'displayButton
        '
        Me.displayButton.Location = New System.Drawing.Point(74, 259)
        Me.displayButton.Name = "displayButton"
        Me.displayButton.Size = New System.Drawing.Size(210, 39)
        Me.displayButton.TabIndex = 17
        Me.displayButton.Text = "Display Type of Hand"
        Me.displayButton.UseVisualStyleBackColor = True
        '
        'handDisplay
        '
        Me.handDisplay.Location = New System.Drawing.Point(74, 306)
        Me.handDisplay.Name = "handDisplay"
        Me.handDisplay.ReadOnly = True
        Me.handDisplay.Size = New System.Drawing.Size(210, 22)
        Me.handDisplay.TabIndex = 18
        '
        'Poker
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(382, 353)
        Me.Controls.Add(Me.handDisplay)
        Me.Controls.Add(Me.displayButton)
        Me.Controls.Add(Me.cardFiveSuitText)
        Me.Controls.Add(Me.cardFourSuitText)
        Me.Controls.Add(Me.cardThreeSuitText)
        Me.Controls.Add(Me.cardTwoSuitText)
        Me.Controls.Add(Me.cardOneSuitText)
        Me.Controls.Add(Me.cardFiveRankText)
        Me.Controls.Add(Me.cardFourRankText)
        Me.Controls.Add(Me.cardThreeRankText)
        Me.Controls.Add(Me.cardTwoRankText)
        Me.Controls.Add(Me.cardOneRankText)
        Me.Controls.Add(Me.CardFiveLabel)
        Me.Controls.Add(Me.cardFourLabel)
        Me.Controls.Add(Me.cardThreeLabel)
        Me.Controls.Add(Me.cardTwoLabel)
        Me.Controls.Add(Me.cardOneLabel)
        Me.Controls.Add(Me.suitLabel)
        Me.Controls.Add(Me.rankLabel)
        Me.Name = "Poker"
        Me.Text = "Poker"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents rankLabel As Label
    Friend WithEvents suitLabel As Label
    Friend WithEvents cardOneLabel As Label
    Friend WithEvents cardTwoLabel As Label
    Friend WithEvents cardThreeLabel As Label
    Friend WithEvents cardFourLabel As Label
    Friend WithEvents CardFiveLabel As Label
    Friend WithEvents cardOneRankText As TextBox
    Friend WithEvents cardTwoRankText As TextBox
    Friend WithEvents cardThreeRankText As TextBox
    Friend WithEvents cardFourRankText As TextBox
    Friend WithEvents cardFiveRankText As TextBox
    Friend WithEvents cardOneSuitText As TextBox
    Friend WithEvents cardTwoSuitText As TextBox
    Friend WithEvents cardThreeSuitText As TextBox
    Friend WithEvents cardFourSuitText As TextBox
    Friend WithEvents cardFiveSuitText As TextBox
    Friend WithEvents displayButton As Button
    Friend WithEvents handDisplay As TextBox
End Class
