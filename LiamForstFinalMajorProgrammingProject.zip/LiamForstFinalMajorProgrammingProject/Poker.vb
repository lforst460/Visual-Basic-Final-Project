﻿Public Class Poker



    ' Create test boolean to make sure the hand is valid
    Dim validHand As Boolean
    'This function makes sure that the character entered is valid, then coverts the suit to a number
    Function convertSuitToIndex(suit As String) As Integer
        If suit = "C" Then
            Return 0
        ElseIf suit = "D" Then
            Return 1
        ElseIf suit = "H" Then
            Return 2
        ElseIf suit = "S" Then
            Return 3
        Else
            validHand = False
            MessageBox.Show("Please fix invalid characters")
        End If
    End Function




    'This function takes the entered data and assigns it to a two-dimensional array
    Function setCardsToArray() As Integer(,)

        ' Reset the validHand value in case of previous attempt to enter invalid data
        validHand = True

        'Assign ranks to cards from text box
        Dim cardOneRank As Integer = CInt(cardOneRankText.Text)
        Dim cardTwoRank As Integer = CInt(cardTwoRankText.Text)
        Dim cardThreeRank As Integer = CInt(cardThreeRankText.Text)
        Dim cardFourRank As Integer = CInt(cardFourRankText.Text)
        Dim cardFiveRank As Integer = CInt(cardFiveRankText.Text)

        'Make sure that the rank numbers are valid
        If cardOneRank < 0 Or cardOneRank > 14 Then
            MessageBox.Show("Please enter a valid number")
            validHand = False
        ElseIf cardTwoRank < 0 Or cardTwoRank > 14 Then
            MessageBox.Show("Please enter a valid number")
            validHand = False
        ElseIf cardThreeRank < 0 Or cardThreeRank > 14 Then
            MessageBox.Show("Please enter a valid number")
            validHand = False
        ElseIf cardFourRank < 0 Or cardFourRank > 14 Then
            MessageBox.Show("Please enter a valid number")
            validHand = False
        ElseIf cardFiveRank < 0 Or cardFiveRank > 14 Then
            MessageBox.Show("Please enter a valid number")
            validHand = False
        End If

        ' Convert suit to number
        Dim cardOneSuit As Integer = convertSuitToIndex(cardOneSuitText.Text)
        Dim cardTwoSuit As Integer = convertSuitToIndex(cardTwoSuitText.Text)
        Dim cardThreeSuit As Integer = convertSuitToIndex(cardThreeSuitText.Text)
        Dim cardFourSuit As Integer = convertSuitToIndex(cardFourSuitText.Text)
        Dim cardFiveSuit As Integer = convertSuitToIndex(cardFiveSuitText.Text)


        ' Exit function to prevent program from if invalid data is entered
        If validHand = False Then
            Exit Function
        End If

        ' Declare a two dimensional hand array with rows for suits and columns for rank
        Dim hand(3, 12) As Integer
        ' Make sure that no identical cards are entered twice
        If hand(cardOneSuit, (cardOneRank - 1)) = 0 Then
            hand(cardOneSuit, (cardOneRank - 1)) = 1
        Else
            validHand = False
            MessageBox.Show("Please fix repeat cards")
        End If
        If hand(cardTwoSuit, (cardTwoRank - 1)) = 0 Then
            hand(cardTwoSuit, (cardTwoRank - 1)) = 1
        Else
            validHand = False
            MessageBox.Show("Please fix repeat cards")
        End If
        If hand(cardThreeSuit, (cardThreeRank - 1)) = 0 Then
            hand(cardThreeSuit, (cardThreeRank - 1)) = 1
        Else
            validHand = False
            MessageBox.Show("Please fix repeat cards")
        End If
        If hand(cardFourSuit, (cardFourRank - 1)) = 0 Then
            hand(cardFourSuit, (cardFourRank - 1)) = 1
        Else
            validHand = False
            MessageBox.Show("Please fix repeat cards")
        End If
        If hand(cardFiveSuit, (cardFiveRank - 1)) = 0 Then
            hand(cardFiveSuit, (cardFiveRank - 1)) = 1
        Else
            validHand = False
            MessageBox.Show("Please fix repeat cards")
        End If
        Return hand
    End Function

    'Function that checks if the hands are a flush
    Function checkForFlush(newHand As Integer(,)) As Boolean
        'Create a variable to keep track of same suits
        Dim suitCheck As Integer
        ' Loop through the rows of the array
        For i As Integer = 0 To 3
            ' Set tracker variable to 0 after checking each row
            suitCheck = 0
            ' Loop through the columns of the array
            For j As Integer = 0 To 12
                ' Add one to tracker variable for each identical suit in a row
                suitCheck += newHand(i, j)
                ' Return true if the suits in a row are the same as the number of cards in a hand
                If suitCheck = 5 Then
                    Return True
                End If
            Next
        Next
        Return False
    End Function

    ' Function to check for straight
    Function checkForStraight(newHand As Integer(,)) As Boolean
        ' Declare varaibles to keep track of what card numbers are in a hand and how many are next to each other
        Dim straightCount As Integer = 0
        Dim previousIndex As Integer = -1
        ' Declare variable to check for ace so it can count as before two or after King
        Dim aceCheck As Boolean = False
        For i As Integer = 0 To 12
            For j As Integer = 0 To 3
                ' Check if there is an ace in the hand
                If newHand(j, i) = 1 And i = 0 Then
                    aceCheck = True
                End If
                ' Track which card has the lowest value 
                If newHand(j, i) = 1 And previousIndex = -1 Then
                    straightCount += 1
                    previousIndex = i
                    ' Check if the cards with the next lowest value is one more than previous value
                ElseIf newHand(j, i) = 1 And i = previousIndex + 1 Then
                    straightCount += 1
                    previousIndex = i
                    ' Make an exception for the possibility of a straight with an ace above a King
                ElseIf newHand(j, i) = 1 And aceCheck = True And previousIndex = 0 And i = 9 Then
                    straightCount += 1
                    previousIndex = i
                End If
            Next
        Next
        ' Check if there were 5 cards with consecutive ranks
        If straightCount = 5 Then
            Return True
        Else
            Return False
        End If
    End Function

    'Function to check for a straight flush
    Function checkForStraightFlush(newHand As Integer(,)) As Boolean
        ' Check if the hand is both a straight and a flush
        If checkForStraight(newHand) And checkForFlush(newHand) Then
            Return True
        Else
            Return False
        End If
    End Function

    ' Function to check for four-of-a-kind
    Function checkForFourOfAKind(newHand As Integer(,)) As Boolean
        ' Declare variable to keep track of cards with same rank
        Dim fours As Integer
        ' Loop through columns of the array
        For i As Integer = 0 To 12
            ' Set tracker variable to 0 for each new column
            fours = 0
            For j As Integer = 0 To 3
                ' Add one to tracker variable for each card in a column
                fours += newHand(j, i)
                ' Return true if tracker variable reaches 4 in a column
                If fours = 4 Then
                    Return True
                End If
            Next
        Next
        Return False
    End Function

    ' Function to check for a full house
    Function checkForFullHouse(newHand As Integer(,)) As Boolean
        'Declare variables to keep track of sets of cards with same rank, and the index of a three-of-a-kind
        Dim pairs As Integer
        Dim threes As Integer
        Dim oldIndex As Integer = 0
        ' Create test boolean to check for a three-of-a-kind
        Dim testBool As Boolean = False
        ' Loop through columns of the array
        For i As Integer = 0 To 12
            ' Set three-of-a-kind tracker variable to 0 for each new column
            threes = 0
            For j As Integer = 0 To 3
                ' Add one to three-of-a-kind tracker variable for each card in a column
                threes += newHand(j, i)
                ' Set test boolean to true and keep track of the index of the three-of-a-kind
                If threes = 3 Then
                    testBool = True
                    oldIndex = i
                    Exit For
                End If
                If oldIndex > 0 Then
                    Exit For
                End If
            Next
        Next
        ' Loop through columns of the array again
        For i As Integer = 0 To 12
            ' Set pair tracker variable to 0 for each new column 
            pairs = 0
            For j As Integer = 0 To 3
                ' Add one to pair tracker variable for each card in a column
                pairs += newHand(j, i)
                ' Return true if pair tracker variable reaches true at a different index from the three-of-a-kind
                If pairs = 2 And i <> oldIndex And testBool Then
                    Return True
                End If
            Next
        Next
        Return False
    End Function

    ' Function to check for a three-of-a-kind
    Function checkForThreeOfAKind(newHand As Integer(,)) As Boolean
        'Declare variable to keep track of cards with same rank
        Dim threes As Integer
        ' Loop through columns of the array
        For i As Integer = 0 To 12
            ' Set tracker variable to 0 for each new column
            threes = 0
            For j As Integer = 0 To 3
                ' Add one to tracker variable for each card in a column
                threes += newHand(j, i)
                ' Return true if tracker variable reaches 3 in a column 
                If threes = 3 Then
                    Return True
                End If
            Next
        Next
        Return False
    End Function

    ' Function to check for a two pair
    Function checkForTwoPair(newHand As Integer(,)) As Boolean
        ' Declare variables to keep track of sets of cards with same rank and the index of the first pair
        Dim pairs As Integer
        Dim newIndex As Integer = 0
        Dim newPair As Integer
        ' Loop through columns of the array
        For i As Integer = 0 To 12
            ' Set first pair tracker variable to 0 for each new column 
            pairs = 0
            For j As Integer = 0 To 3
                ' Add one to first pair tracker variable for each card in a column
                pairs += newHand(j, i)
                ' Save the index of where the first pair tracker variable reaches 2
                If pairs = 2 Then
                    newIndex = i + 1
                    Exit For
                End If
                If newIndex > 0 Then
                    Exit For
                End If
            Next
        Next
        ' Loop through array starting at the index of the first pair
        For i As Integer = newIndex To 12
            ' Set second pair tracker variable to 0 for each new column
            newPair = 0
            For j As Integer = 0 To 3
                ' Add one to second pair tracker variable for each card in a column
                newPair += newHand(j, i)
                ' Return true if there is a second pair after the first pair
                If newPair = 2 Then
                    Return True
                End If
            Next
        Next
        Return False
    End Function

    'Function to check for a one pair
    Function checkForOnePair(newHand As Integer(,)) As Boolean
        'Declare variable to keep track of cards with same rank
        Dim pairs As Integer
        ' Loop through columns of the array
        For i As Integer = 0 To 12
            ' Set tracker variable to zero for each new column 
            pairs = 0
            For j As Integer = 0 To 3
                ' Add one to tracker variable for each card in a column
                pairs += newHand(j, i)
                ' Return true if tracker variable reaches 2 in a column
                If pairs = 2 Then
                    Return True
                End If
            Next
        Next
        Return False
    End Function

    ' Sub to check what type of hand was entered
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles displayButton.Click
        ' Create array currentHand set to the values entered in the text boxes
        Dim currentHand As Integer(,) = setCardsToArray()
        ' Make sure that the data entered is valid
        If validHand = False Then
            Exit Sub
        End If
        ' Use functions to check what the highest possible hand is and display what type of hand that is in the text box
        If checkForStraightFlush(currentHand) Then
            handDisplay.Text = "The hand is a straight flush"
        ElseIf checkForFourOfAKind(currentHand) Then
            handDisplay.Text = "The hand is a four-of-a-kind"
        ElseIf checkForFullHouse(currentHand) Then
            handDisplay.Text = "The hand is a full house"
        ElseIf checkForFlush(currentHand) Then
            handDisplay.Text = "The hand is a flush"
        ElseIf checkForStraight(currentHand) Then
            handDisplay.Text = "The hand is a straight"
        ElseIf checkForThreeOfAKind(currentHand) Then
            handDisplay.Text = "The hand is a three-of-a-kind"
        ElseIf checkForTwoPair(currentHand) Then
            handDisplay.Text = "The hand is a two pair"
        ElseIf checkForOnePair(currentHand) Then
            handDisplay.Text = "The hand is a one pair"
        Else
            handDisplay.Text = "The hand is none of the above"
        End If
    End Sub
End Class
